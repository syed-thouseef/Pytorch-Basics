require('dotenv').config();
// Setup the Proxy for the Web client:
const HttpsProxyAgent = require('https-proxy-agent');
const token = process.env.BOT_TOKEN;

// Set proxy 
const proxy = new HttpsProxyAgent(process.env.http_proxy || 'http://proxy.ebiz.verizon.com:80');

// _________________________________________________________________________________

const { App} = require('@slack/bolt');

    
// ____________________________________________________________________

const app = new App({
  agent : proxy, 
  socketMode:true,  
  token: process.env.BOT_TOKEN,
  signingSecret: process.env.SIGNING_SECRET,
  appToken: process.env.APP_TOKEN
  
});


// Require the Node Slack SDK package (github.com/slackapi/node-slack-sdk)
// const { WebClient, LogLevel } = require("@slack/web-api");

// WebClient insantiates a client that can call API methods
// When using Bolt, you can use either `app.client` or the `client` passed to listeners.
// const client = new WebClient(token, {
//   // LogLevel can be imported and used to make debugging simpler
//   logLevel: LogLevel.DEBUG
// });

// client = new app.client(process.env.BOT_TOKEN)

// ID of user you watch to fetch information for
const userId = "U01JS47M7LM";

(async () => {
  // Start the app
  await app.start(process.env.PORT || '3200');

  console.log('⚡️ Bolt app is running!');

  try {
    // Call the users.info method using the WebClient
    const result = await app.client.users.info({
      user: userId,
      token:token
    });
  
    console.log(`${result.user.real_name}`);
  }
  catch (error) {
    console.error(error);
  }

})();


