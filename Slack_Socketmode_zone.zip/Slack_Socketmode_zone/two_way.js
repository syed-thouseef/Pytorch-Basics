var url = require('url');
var request = require('request');
var WebSocket = require('ws');

// ________________________________________________________________________________________________________
require('dotenv').config();
// Setup the Proxy for the Web client:
const HttpsProxyAgent = require('https-proxy-agent');
const token = process.env.BOT_TOKEN;

// Set proxy 
const proxy = new HttpsProxyAgent(process.env.http_proxy || 'http://proxy.ebiz.verizon.com:80');

// _________________________________________________________________________________

const { App} = require('@slack/bolt');

    
// ____________________________________________________________________

const app = new App({
  agent : proxy, 
  socketMode:true,  
  token: process.env.BOT_TOKEN,
  signingSecret: process.env.SIGNING_SECRET,
  appToken: process.env.APP_TOKEN
  
});



console.log("starting port");

request({
  'url':'https://slack.com/api/apps.connections.open',
  'method': "POST",
  'proxy':'http://proxy.ebiz.verizon.com:80',
  'headers' : {
    "Content-Type": "application/x-www-form-urlencoded",
    "Authorization": 'Bearer xapp-1-A01MWCFGNNM-1755653673568-29c50ec5718de5ca8b00f67d412e1f068cd851d985c75df8a5864939177d1266',


  }
},function (error, response, body) {
  if (!error && response.statusCode == 200) {
    console.log(typeof(body));

    if(typeof (body)=="string")
    body=JSON.parse(body);
    // body=response.body;
    console.log(typeof(body))
    console.log(body.url)

    let wssUrl = body.url;
    console.log(typeof(wssUrl))

    let socket = new WebSocket(wssUrl);

    socket.onopen = function(event) {
      
        socket.send(JSON.stringify(event.msg))
      
    
          
        // connection established
      }
  
      // socket.send(JSON.stringify(msg))
  
      
      socket.onmessage = function(event) {
        // application received message
        
        let _data = JSON.parse(event.data);
        console.log(_data);
        app.message('hello', async ({ message, say }) => {
          await say(`Hello, <@${message.user}>`);
        });
    
      }
  
      
    }
    
  })







// require('dotenv').config();
// // Setup the Proxy for the Web client:
// const HttpsProxyAgent = require('https-proxy-agent');
// const token = process.env.BOT_TOKEN;

// // Set proxy 
// const proxy = new HttpsProxyAgent(process.env.http_proxy || 'http://proxy.ebiz.verizon.com:80');

// // _________________________________________________________________________________

// const { App} = require('@slack/bolt');

    
// // ____________________________________________________________________

// const app = new App({
//   agent : proxy, 
//   socketMode:true,  
//   token: process.env.BOT_TOKEN,
//   signingSecret: process.env.SIGNING_SECRET,
//   appToken: process.env.APP_TOKEN
  
// });



  



// console.log("starting port");
/* Add functionality here */  
// (async () => {
//     // Start the app
//     await app.start(process.env.PORT || '3000');
  
//     console.log('⚡️ Bolt app is running!');
// })();

// app.message('hello', async ({ message, say }) => {
//     await say(`Hello, <@${message.user}>`);
//   });





