require('dotenv').config();
// Setup the Proxy for the Web client:
const HttpsProxyAgent = require('https-proxy-agent');
const token = process.env.BOT_TOKEN;

// Set proxy 
const proxy = new HttpsProxyAgent(process.env.http_proxy || 'http://proxy.ebiz.verizon.com:80');

// _________________________________________________________________________________

const { App} = require('@slack/bolt');

    
// ____________________________________________________________________

const app = new App({
  agent : proxy, 
  socketMode:true,  
  token: process.env.BOT_TOKEN,
  signingSecret: process.env.SIGNING_SECRET,
  appToken: process.env.APP_TOKEN
  
});
console.log("starting port");
/* Add functionality here */  

(async () => {
  // Start the app
  await app.start(process.env.PORT || '3200');

  console.log('⚡️ Bolt app is running!');

})();


app.message('message', async ({ event, client }) => {

  ///////
  console.log(event)
  var userId = event.user;
  
    // Call the users.info method using the WebClient
    const result = await client.users.info({
      user: userId
    });
  
    console.log(result);



// /////

    try {
      // Call chat.postMessage with the built-in client
      const response = await client.chat.postMessage({
        token: process.env.BOT_TOKEN,
        channel: "D01N8AW7USC",
        text: `Response from the script`
      });
      
      // console.log(event);
      console.log(response)

      if(response.ok == true){
        
        console.log(`Message was sent with response: ok: ${response.ok}`)
      }
      else if(response.ok== false){ 
        throw new Error(`Message was not sent with response: ok: ${response.ok}`)
        // console.log(`Message was not sent with response: ok: ${response.ok}`)
       
    }





    }
    catch (error) {
      console.error(error.data);
    }
    
  });





// app.action('message', async ({ action, ack, respond }) => {
//     await ack();
//     await respond(`You selected <@${action.selected_user}>`);
//   });







 


















   
  

























