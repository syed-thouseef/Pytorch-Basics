// npm install log-to-file --save

require('dotenv').config();
// Setup the Proxy for the Web client:
const HttpsProxyAgent = require('https-proxy-agent');
const token = process.env.BOT_TOKEN;

// Set proxy 
const proxy = new HttpsProxyAgent(process.env.http_proxy || 'http://proxy.ebiz.verizon.com:80');

// _________________________________________________________________________________

const { App} = require('@slack/bolt');

    
// ____________________________________________________________________

const app = new App({
  agent : proxy, 
  socketMode:true,  
  token: process.env.BOT_TOKEN,
  signingSecret: process.env.SIGNING_SECRET,
  appToken: process.env.APP_TOKEN
  
});
console.log("starting port");
///////////////////////////////////////////////////////////////////
// global.bot_uc = "UC721";
// global.bot_message = "Failed";
// global.bot_user_email = "vztest@example.com";
// global.bot_environment = "DEV"
// global.bot_host_name = "Sample_Host"

// global.approve_status = "";
// global.user_selection = "NONE";

// var main_dict = {
//     bot_uc : "UC721",
//     bot_message : "Failed",
//     bot_user_email : "vztest@example.com",
//     bot_environment : "DEV",
//     bot_host_name : "Sample_Host",
//     block_id : "",
//     approve : "NOT_selected",
//     deny : "NOT_selected",
//     user_sel : "NOT_selected",
//     escalevel: "NOT_selected"
// }

function init_dict(){
    var main_dict = {
        bot_uc : "UC721",
        bot_message : "Failed",
        bot_user_email : "vztest@example.com",
        bot_environment : "PROD",
        bot_host_name : "Sample_Host",
        block_id : "",
        assign : "NOT_selected",
        ignore : "NOT_selected",
        user_sel : "NOT_selected",
        escalevel: "NOT_selected",
        assigner: "NOT_selected",
        timestamp : "NOT_selected"
    }


    bot_uc1 = main_dict["bot_uc"];
    bot_message1 = main_dict["bot_message"];
    bot_user_email1 = main_dict["bot_user_email"];
    bot_environment1 = main_dict["bot_environment"];
    bot_host_name1 = main_dict["bot_host_name"];
    block_id1 = main_dict["block_id"];
    assign1 = main_dict["assign"];
    ignore1 = main_dict["ignore"];
    user_sel1 = main_dict["user_sel"];
    escalevel1 = main_dict["escalevel"];
    assigner1 = main_dict["assigner"];
    timestamp1 = main_dict["timestamp"];

    
    return bot_uc1,bot_message1, bot_user_email1, bot_environment1, bot_host_name1, block_id1, assign1, ignore1, user_sel1, escalevel1, assigner1,timestamp1;

}

// bot_uc1 = main_dict["bot_uc"];
// bot_message1 = main_dict["bot_message"];
// bot_user_email1 = main_dict["bot_user_email"];
// bot_environment1 = main_dict["bot_environment"];
// bot_host_name1 = main_dict["bot_host_name"];
// block_id1 = main_dict["block_id"];
// approve1 = main_dict["approve"];
// deny1 = main_dict["deny"];
// user_sel1 = main_dict["user_sel"];
// escalevel1 = main_dict["escalevel"];



function update_Function(bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1) {

    var dict = {
        bot_uc : bot_uc1,
        bot_message : bot_message1,
        bot_user_email : bot_user_email1 ,
        bot_environment : bot_environment1,
        bot_host_name : bot_host_name1,
        block_id : block_id1,
        assign : assign1,
        ignore: ignore1,
        user_sel : user_sel1,
        escalevel : escalevel1,
        assigner : assigner1,
        timestamp : timestamp1
    }

    return dict;   
  }


////////////////////////////////////////////////////////////////

(async () => {
    // Start the app
    await app.start(process.env.PORT || '3200');
  
    console.log('⚡️ Bolt app is running!');
  
  })();

/////////////////////////////////////

app.event('message', async ({ event, client }) => {

    ///////
    console.log(event)

    let source = `${event.text}`;

    var initialize_params = init_dict();

    initialize_params

    let auth_user_source = `${event.bot_id}`;

    // var userId =`${event.user}`;
  
    // // Call the users.info method using the WebClient
    // const result = await client.users.info({
    //   user: userId
    // });
  
    // console.log(result);

   

    // Test App channel: D01N8AW7USC
    // Common private channel (chatbot-test): G01KKB1CYBT
    // Milo channel : D01KUTM8CQG
    console.log(source.search("control_room"))

    // if(source.search("control_room") != -1 && auth_user_source == "B01KFH9S5T3")
  
  
if(source.search("control_room") != -1 )
  {
    try{
        app.client.chat.postMessage({
              token: process.env.BOT_TOKEN,
              channel: "chatbot-test-three",
              "blocks": [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": "Bot Alert\n",
                       
                    }
                },
                {
                    "type": "section",
                    "fields": [
                        {
                            "type": "mrkdwn",
                            "text": `*Bot Name *\n ${bot_uc1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `*Bot Message*\n ${bot_message1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `*User Email*\n${bot_user_email1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `*Environment*\n${bot_environment1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `*Host name*\n ${bot_host_name1}`
                        }
                    ]
                },
                {
                    "type": "actions",
                    "elements": [
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "emoji": true,
                                "text": "Assign"
                            },
                            "style": "primary",
                            "value": `${bot_uc1}_${bot_message1}_${bot_host_name1}_${bot_user_email1}_${bot_environment1}`,
                            "action_id" : `assign_button`
                            
                        },
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "emoji": true,
                                "text": "Ignore"
                            },
                            "style": "danger",
                            "value": `${bot_uc1}_${bot_message1}_${bot_host_name1}_${bot_user_email1}_${bot_environment1}`,
                            "action_id" : `ignore_button`
                        }
                        ,
                        {
                            "type": "users_select",                           
                            "placeholder": {
                                "type": "plain_text",
                                "text": "Select a user",
                                "emoji": true
                            },
                            "action_id": "user_actionId"
                        },     
                        {
                            "type": "static_select",
                            "placeholder": {
                                "type": "plain_text",
                                "text": "Select the Priority Level",
                                "emoji": true
                            },
                            "options": [
                                {
                                    "text": {
                                        "type": "plain_text",
                                        "text": "*High*",
                                        "emoji": true
                                    },
                                    "value": `value-0`
                                },
                                {
                                    "text": {
                                        "type": "plain_text",
                                        "text": "*Medium*",
                                        "emoji": true
                                    },
                                    "value": "value-1"
                                },
                                {
                                    "text": {
                                        "type": "plain_text",
                                        "text": "*Low*",
                                        "emoji": true
                                    },
                                    "value": "value-2"
                                }
                            ],
                            "action_id": `escalation_actionId`
                        }
                        
                    ]
                }
            ]
    
    
          })
          
           
      } 
      
      catch (error) {
          console.error(error);
      }
    }
      
});

// _____________________________________
function chat_update(message_timestamp,bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1,priority_level,user_selection_checker,action_value,assigner1) {

    
    try{
        app.client.chat.postMessage({
              token: process.env.BOT_TOKEN,
              channel: "chatbot-test-three",
              ts : message_timestamp,
              "blocks": [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": "Bot Alert\n",
                       
                    }
                },
                {
                    "type": "section",
                    "fields": [
                        {
                            "type": "mrkdwn",
                            "text": `*Bot Name *\n ${bot_uc1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `*Bot Message*\n ${bot_message1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `*User Email*\n${bot_user_email1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `*Environment*\n${bot_environment1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `*Host name*\n ${bot_host_name1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `\n☑️ Thank you! The Assign button for ${action_value} done by <@${assigner1}> ✅\n\n The task is assigned to <@${user_selection_checker}> with the Priority Level ${priority_level} `
                        }
                    ]
                }
            ]
    
    
          })
          
           
      } 
      
      catch (error) {
          console.error(error);
      }
    


}


// _____________________________________





app.action('assign_button', async ({ action, ack, say, context, body}) => {
   
    console.log('assign button clicked');
    console.log('Checking Block values')
    console.log(body.state.values)
  
// _____________________________________

// var userId = "U01JS47M7LM"
// const result =  await client.users.info({
//     user: userId
//   });


// console.log(result)

// _______________________________________

    // _________________________________________________________________
    console.log("checking block id")
    console.log("Displaying state values under assign block")
    block_id1 = `${action.block_id}`
    console.log(body.state.values[block_id1].user_actionId.selected_user)

    var user_selection_checker = `${body.state.values[block_id1].user_actionId.selected_user}`

    var priority_selection_checker = `${body.state.values[block_id1].escalation_actionId.selected_option}`

    

    

    if(user_selection_checker === "null" || priority_selection_checker === "null"){
        await say("You have not selected the User or the Priority Level! ⚠️ \n\n *Note:* Once you have selected both the *User* and the *Priority Level*, Click Assign ")
    }
    else{

        var priority_level = `${body.state.values[block_id1].escalation_actionId.selected_option.text.text}`

        var message_timestamp = `${body.container.message_ts}`

        var action_value = `${action.value}`

        var assigner1 = `${body.user.id}`

        // await say(`Thank you! You just clicked the Assign button for ${action.value} done by <@${body.user.id}> ✅\n\n The task is assigned to <@${user_selection_checker}> with the Priority Level ${priority_level}  `);
        await chat_update(message_timestamp,bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1,user_selection_checker,priority_level,action_value,assigner1);


    
    }

  

    // ________________________________________________________________

    

    // await say(`Thank you! You just clicked the Assign button for ${action.value} done by <@${body.user.id}> , \n\n *Now select the user that needs to be assigned to the task*`);
    
    // await console.log("Message was sent")

    assign_status = true;
    // await console.log(Boolean(assign_status))
    block_id1 = `${action.block_id}`
    assign1 = Boolean(assign_status)

    
    // ______________________________________________________________________
    // Retreive timestamp
    var ts1 = Number(`${action.action_ts}`)
    var ts = ts1*1000;
    var date = new Date(ts);
    var timestamp1 = ("Date: "+date.getDate()+
          "/"+(date.getMonth()+1)+
          "/"+date.getFullYear()+
          " "+date.getHours()+
          ":"+date.getMinutes()+
          ":"+date.getSeconds());
    // _______________________________________________________________________
    // Dictionary update 
    var escalevel1 = priority_level;
    var user_sel1 = user_selection_checker;

    tracking = update_Function(bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1)
    console.log(tracking)

    

    // update_result = chat_update(message_timestamp,bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1);

    // console.log(update_result)

    

    
  })


// /////////////////////

app.action('ignore_button', async ({ action, ack, say, context, body }) => {
    console.log('ignore button clicked');
    
    // Acknowledge action request
    console.log(action)

    assigner1 = `${body.user.id}`
  
    console.log(action.value)
    await say(`Thank you! You just clicked the Ignore button for ${action.value} done by <@${body.user.id}> `);
    

    ignore_status = true;
    await console.log(Boolean(ignore_status))
    block_id1 = `${action.block_id}`
    ignore1 = Boolean(ignore_status)
        // ______________________________________________________________________
    // Retreive timestamp
    var ts1 = Number(`${action.action_ts}`)
    var ts = ts1*1000;
    var date = new Date(ts);
    var timestamp1 = ("Date: "+date.getDate()+
          "/"+(date.getMonth()+1)+
          "/"+date.getFullYear()+
          " "+date.getHours()+
          ":"+date.getMinutes()+
          ":"+date.getSeconds());
    // _______________________________________________________________________

    tracking = update_Function(bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1)
    console.log(tracking)

    

    
  });


//////////////////////////////////
app.action('user_actionId', async ({ action, ack, say,context,body }) => {
    console.log('user selection button clicked');
    
    // Acknowledge action request
    await ack();
    console.log(body.state.values)

  
    
    assigner1 = `${body.user.id}`


    
    // const output = outcome
    // await esfunc();
    // await console.log(output)

    // global.user_selection = `${action.selected_user}`
    // user_selection = `<@${action.selected_user}>`
    block_id1 = `${action.block_id}`
    user_sel1 = `<@${action.selected_user}>`

    // var tracking = update_Function(bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1)
    // console.log(tracking)

    

    await say(`You have assigned the user <@${action.selected_user}> `);

    
  });




////////////////////////////////

app.action('escalation_actionId', async ({ action, ack, say, context,body }) => {
    console.log('button clicked');
    
    console.log(body);
    // Acknowledge action request
    await ack();
    await console.log(action)

    assigner1 = `${body.user.id}`
    block_id1 = `${action.block_id}`

    var escalevel1 = `${action.block_id}`



    // ____________________________________________________
  
  

    // ___________________________________________________

    await say(`Thank you for selecting the escalation level ${action.selected_option.text.text} `);
    var escalevel1 = (`${action.selected_option.text.text}`)
 
    // var tracking = update_Function(bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1)
    // console.log(tracking)


    
  });


//   Log into a file

var fs = require('fs');
var util = require('util');
var log_file = fs.createWriteStream(__dirname + '/debug.log', {flags : 'w'});
var log_stdout = process.stdout;

console.log = function(d) { //
  log_file.write(util.format(d) + '\n');
  log_stdout.write(util.format(d) + '\n');
};


// ////////////////////////////////////////////////////////////////////////////////////////////////////// Chat update after user is assigned
  

//  body.container.message_ts
// function chat_update(message_timestamp,bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1) {

    
//         try{
//             app.client.chat.postMessage({
//                   token: process.env.BOT_TOKEN,
//                   channel: "chatbot-test-three",
//                   "blocks": [
//                     {
//                         "type": "section",
//                         "text": {
//                             "type": "mrkdwn",
//                             "text": "Bot Alert\n",
                           
//                         }
//                     },
//                     {
//                         "type": "section",
//                         "fields": [
//                             {
//                                 "type": "mrkdwn",
//                                 "text": `*Bot Name *\n ${bot_uc1}`
//                             },
//                             {
//                                 "type": "mrkdwn",
//                                 "text": `*Bot Message*\n ${bot_message1}`
//                             },
//                             {
//                                 "type": "mrkdwn",
//                                 "text": `*User Email*\n${bot_user_email1}`
//                             },
//                             {
//                                 "type": "mrkdwn",
//                                 "text": `*Environment*\n${bot_environment1}`
//                             },
//                             {
//                                 "type": "mrkdwn",
//                                 "text": `*Host name*\n ${bot_host_name1}`
//                             }
//                         ]
//                     },
//                     {
//                         "type": "actions",
//                         "elements": [
//                             {
//                                 "type": "button",
//                                 "text": {
//                                     "type": "plain_text",
//                                     "emoji": true,
//                                     "text": "Assign"
//                                 },
//                                 "style": "primary",
//                                 "value": `${bot_uc1}_${bot_message1}_${bot_host_name1}_${bot_user_email1}_${bot_environment1}`,
//                                 "action_id" : `assign_button`
                                
//                             },
//                             {
//                                 "type": "button",
//                                 "text": {
//                                     "type": "plain_text",
//                                     "emoji": true,
//                                     "text": "Ignore"
//                                 },
//                                 "style": "danger",
//                                 "value": `${bot_uc1}_${bot_message1}_${bot_host_name1}_${bot_user_email1}_${bot_environment1}`,
//                                 "action_id" : `ignore_button`
//                             }
//                             ,
//                             {
//                                 "type": "users_select",                           
//                                 "placeholder": {
//                                     "type": "plain_text",
//                                     "text": "Select a user",
//                                     "emoji": true
//                                 },
//                                 "action_id": "user_actionId"
//                             },
//                             {
//                                 "type": "static_select",
//                                 "placeholder": {
//                                     "type": "plain_text",
//                                     "text": "Select the Priority Level",
//                                     "emoji": true
//                                 },
//                                 "options": [
//                                     {
//                                         "text": {
//                                             "type": "plain_text",
//                                             "text": "*High*",
//                                             "emoji": true
//                                         },
//                                         "value": `value-0`
//                                     },
//                                     {
//                                         "text": {
//                                             "type": "plain_text",
//                                             "text": "*Medium*",
//                                             "emoji": true
//                                         },
//                                         "value": "value-1"
//                                     },
//                                     {
//                                         "text": {
//                                             "type": "plain_text",
//                                             "text": "*Low*",
//                                             "emoji": true
//                                         },
//                                         "value": "value-2"
//                                     }
//                                 ],
//                                 "action_id": `escalation_actionId`
//                             }
                            
//                         ]
//                     }
//                 ]
        
        
//               })
              
               
//           } 
          
//           catch (error) {
//               console.error(error);
//           }
        


// }
