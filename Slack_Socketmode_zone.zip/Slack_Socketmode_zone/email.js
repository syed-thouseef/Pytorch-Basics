
var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  host: 'vzsmtp.verizon.com',
  port: 25,
  auth: {
      user: "syedth1",
      pass: ""
  }
});

message = {
  from: "thouseef.syed@verizon.com",
  to: "thouseef.syed@verizon.com",
  subject: "Subject",
  text: "Hello SMTP Email"
}

transporter.sendMail(message, function(err, info) {
  if (err) {
    console.log(err)
  } else {
    console.log(info);
  }
})