require('dotenv').config();
// Setup the Proxy for the Web client:
const HttpsProxyAgent = require('https-proxy-agent');
const token = process.env.BOT_TOKEN;

// Set proxy 
const proxy = new HttpsProxyAgent(process.env.http_proxy || 'http://proxy.ebiz.verizon.com:80');

// _________________________________________________________________________________

const { App} = require('@slack/bolt');

    
// ____________________________________________________________________

const app = new App({
  agent : proxy, 
  socketMode:true,  
  token: process.env.BOT_TOKEN,
  signingSecret: process.env.SIGNING_SECRET,
  appToken: process.env.APP_TOKEN
  
});

// ___________________________________________________________________________________________________
const https = require('https')

;
// const options = {
//   hostname: 'proxy.ebiz.verizon.com',
//   path : 'https://slack.com/api/apps.connections.open',
//   port: 80,
//   method: 'POST',
//   headers: {
//     'Content-Type': 'application/x-www-form-urlencoded',
//     'Authorization':'Bearer xapp-1-A01MWCFGNNM-1755653673568-29c50ec5718de5ca8b00f67d412e1f068cd851d985c75df8a5864939177d1266'
//   }
// }

// const req = https.request(options, res => {
//   console.log(`statusCode: ${res.statusCode}`)

// })

// req.on('error', error => {
//   console.error(error)
// })

// req.end()

////////////////////////////////////////////////////////////////////////////////

  
// let options = {
//     hostname: "proxy.ebiz.verizon.com",
//     path: "https://slack.com/api/apps.connections.open",
//     method: "GET",
//     port: 80,
//     headers: {
//       "Content-Type": "application/x-www-form-urlencoded",
//       "Authorization": 'Bearer xapp-1-A01MWCFGNNM-1755653673568-29c50ec5718de5ca8b00f67d412e1f068cd851d985c75df8a5864939177d1266'
//     }
//   }
  
// https.request(options, res => {
//       let data = ""
//       res.on("data", d => {
//         data += d
//       })
//       res.on("end", () => {
//         console.log(data)
//       })
//     })
//     .on("error", console.error)
 


/////////////////////////////////////////////////////////////////////////

var url = require('url');
var request = require('request');
var WebSocket = require('ws');

request({
  'url':'https://slack.com/api/apps.connections.open',
  'method': "POST",
  'proxy':'http://proxy.ebiz.verizon.com:80',
  'headers' : {
    "Content-Type": "application/x-www-form-urlencoded",
    "Authorization": 'Bearer xapp-1-A01MWCFGNNM-1755653673568-29c50ec5718de5ca8b00f67d412e1f068cd851d985c75df8a5864939177d1266',


  }
},function (error, response, body) {
  if (!error && response.statusCode == 200) {
    console.log(typeof(body));

    if(typeof (body)=="string")
    body=JSON.parse(body);
    // body=response.body;
    console.log(typeof(body))
    console.log(body.url)

    let wssUrl = body.url;
    console.log(typeof(wssUrl))

    let socket = new WebSocket(wssUrl);

  
    socket.onopen = function(event) {
     
      // socket.send(JSON.stringify(event.msg))
    
  
        
      // connection established
    }

    // socket.send(JSON.stringify(msg))

    function post(channel_ID){
      try {
          
        console.log(channel_ID)
        // Call the chat.postMessage method using the WebClient
        const result = app.client.chat.postMessage({
          token: process.env.BOT_TOKEN,
          channel: channel_ID,
          text: "Hello from the backend script"
        });
        
        console.log(result);
      }
      catch (error) {
        console.error(error);
      }
    }
    

    
    socket.onmessage = async function(event) {
      // application received message
  
      let _data = JSON.parse(event.data);
      console.log(_data)

      const connected = await _data.payload;
      if(connected) {
        let incoming_message =  await _data.payload.event.text

      console.log("connected")
      console.log(incoming_message)

      const channel_ID = await _data.payload.event.channel
      post(channel_ID)
      


   

      
    }

    // socket.onmessage().then(post(channel_ID))

    }
    

    



    
  }
  
  



    
  
})

// async function post(channel_ID){

//   try {
    
//     console.log(channel_ID)
//     // Call the chat.postMessage method using the WebClient
//     const result = await app.client.chat.postMessage({
//       token: process.env.BOT_TOKEN,
//       channel: channel_ID,
//       text: "Hello from the backend script"
//     });
    
//     console.log(result);
//   }
//   catch (error) {
//     console.error(error);
//   }
// }


// request({
//     'url':'https://slack.com/api/chat.postMessage',
//     'method': "POST",
//     'proxy':'http://proxy.ebiz.verizon.com:80',
//     'headers' : {
//       "Content-Type": "application/json",
//       "Authorization": 'Bearer xoxb-1111176898965-1732471805266-GrLBsBLWap4h5hUk31Ib4yRh'
//     },
//     'json': {"channel":"D01N8AW7USC",
//       "text":"Sending test message from script",
//       }
// },function (error, response, body) {
//         if (!error && response.statusCode == 200) {
//           console.log(body);
      
        

//         }
//     })



































      




















