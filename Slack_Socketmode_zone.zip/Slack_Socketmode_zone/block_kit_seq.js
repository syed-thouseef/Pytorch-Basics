require('dotenv').config();
// Setup the Proxy for the Web client:
const HttpsProxyAgent = require('https-proxy-agent');
const token = process.env.BOT_TOKEN;

// Set proxy 
const proxy = new HttpsProxyAgent(process.env.http_proxy || 'http://proxy.ebiz.verizon.com:80');

// _________________________________________________________________________________

const { App} = require('@slack/bolt');

    
// ____________________________________________________________________

const app = new App({
  agent : proxy, 
  socketMode:true,  
  token: process.env.BOT_TOKEN,
  signingSecret: process.env.SIGNING_SECRET,
  appToken: process.env.APP_TOKEN
  
});
console.log("starting port");
/* Add functionality here */  

(async () => {
  // Start the app
  await app.start(process.env.PORT || '3000');

  console.log('⚡️ Bolt app is running!');
  try{
    app.client.chat.postMessage({
          token: process.env.BOT_TOKEN,
          channel: "D01N8AW7USC",
          "blocks": [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "Bot Alert\n",
                   
                }
            },
            {
                "type": "section",
                "fields": [
                    {
                        "type": "mrkdwn",
                        "text": "*Bot Name *\n UC 700"
                    },
                    {
                        "type": "mrkdwn",
                        "text": "*Bot Message*\n Failed"
                    },
                    {
                        "type": "mrkdwn",
                        "text": "*User Email*\nvztest@example.com"
                    },
                    {
                        "type": "mrkdwn",
                        "text": "*Environment*\nDEV"
                    },
                    {
                        "type": "mrkdwn",
                        "text": "*Host name*\n Sample_Host"
                    }
                ]
            },
            {
                "type": "actions",
                "elements": [
                    {
                        "type": "button",
                        "text": {
                            "type": "plain_text",
                            "emoji": true,
                            "text": "Approve"
                        },
                        "style": "primary",
                        "value": "click_me_123",
                        "action_id" : "approve_button"
                    },
                    {
                        "type": "button",
                        "text": {
                            "type": "plain_text",
                            "emoji": true,
                            "text": "Deny"
                        },
                        "style": "danger",
                        "value": "click_me_123",
                        "action_id" : "deny_button"
                    }
                    ,
                    {
                        "type": "users_select",                           
                        "placeholder": {
                            "type": "plain_text",
                            "text": "Select a user",
                            "emoji": true
                        },
                        "action_id": "user_actionId"
                    },
                    {
                        "type": "static_select",
                        "placeholder": {
                            "type": "plain_text",
                            "text": "Select an item",
                            "emoji": true
                        },
                        "options": [
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "*High*",
                                    "emoji": true
                                },
                                "value": "value-0"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "*Medium*",
                                    "emoji": true
                                },
                                "value": "value-1"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "*Low*",
                                    "emoji": true
                                },
                                "value": "value-2"
                            }
                        ],
                        "action_id": "escalation_actionId"
                    }
                    
                ]
            }
        ]


      })
     
  }
  catch (error) {
      console.error(error);
  }
})();






app.action('deny_button', async ({ action, ack, respond, context }) => {
    console.log('button clicked');
    
    // Acknowledge action request
    await ack();
    console.log(ack)
    await respond('Thank you! You just clicked the Deny button');

    
  });




/////////////////////////////////////

const esfunc = async() => {
    app.action('escalation_actionId', async ({ action, ack, say, context }) => {
        console.log('escalation button clicked and selected');
        
        // Acknowledge action request
        await ack();
        await console.log(action)
    
        await say(`Thank you for selecting the escalation level ${action.selected_option.text.text} `);
        const output = (`${action.selected_option.text.text}`)
        await output
        await console.log(output)
        return output
    
        
      });
      
  }

//////////////////////////////////////

const useridfunc = async() => {
    app.action('user_actionId', async ({ action, ack, say,context}) => {
    console.log('User button clicked and selected');
    
    // Acknowledge action request
    await ack();

   

    // const actions = JSON.parse(action)
    // console.log(actions)
    // console.log(actions.selected_user)
 
    await console.log(action)
    await console.log(ack)



    // const main_escal = async () =>{
    //     const outcome = await esfunc()
    //     return outcome
    // }

    
    

    // main_escal() // returns a promise

    // (async () => {
    //     console.log(await main_escal())
    //     console.log("Inside the wrapper")
    //   })()
    // const output = outcome
    // await esfunc();
    // await console.log(output)

    await say(`Thank you for selecting the user <@${action.selected_user}> `);

    const userId = `<@${action.selected_user}>`;

    

//     try {
//         // Call the users.info method using the WebClient
//         const result = await client.users.info({
//             user: userId
//   });

//   console.log(result);
// }
// catch (error) {
//   console.error(error);
// }



    
  });

}

app.action('approve_button', async ({ action, ack, say, context, client}) => {
    console.log('button clicked');
    
    app.action.name
    console.log(action.response_url)
    // Acknowledge action request
    var i;
    for (i=0;i<1;i++){
    await useridfunc();
    await esfunc();
    
    }
    console.log(i)
    
    if(i==1){
    
  
    console.log(action)
    await say(`Thank you! You just clicked the Approve button <@${action}>`);
    
    await console.log("Message was sent")

    }



    
  })


// function esfunc() {
//     app.action('escalation_actionId', async ({ action, ack, respond, context }) => {
//         console.log('button clicked');
        
//         // Acknowledge action request
//         await ack();
//         await console.log(action)
    
//         // await respond(`Thank you for selecting the escalation level ${action.selected_option.text.text} `);
//         var output = (`${action.selected_option.text.text}`)
//         return output
    
        
//       });
//   }
  

// app.action('escalation_actionId', async ({ action, ack, respond, context }) => {
//     console.log('button clicked');
    
//     // Acknowledge action request
//     await ack();
//     await console.log(action)

//     await respond(`Thank you for selecting the escalation level ${action.selected_option.text.text} `);

    
//   });





  




















// app.message('hello', async ({ message, say }) => {
//     await say(`Hello, <@${message.user}>`);
//   });



// app.action('message', async ({ action, ack, respond }) => {
//     await ack();
//     await respond(`You selected <@${action.selected_user}>`);
//   });



// app.event('message', async ({ event, client }) => {
//     try {
//       // Call chat.postMessage with the built-in client
//       const result = await client.chat.postMessage({
//         token: process.env.BOT_TOKEN,
//         channel: "D01N8AW7USC",
//         text: `Response from script using app.events`
//       });
//       console.log(app.event);
//     }
//     catch (error) {
//       console.error(error);
//     }
//   });







