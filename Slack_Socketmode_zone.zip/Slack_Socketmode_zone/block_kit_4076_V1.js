// npm install log-to-file --save

require('dotenv').config();
// Setup the Proxy for the Web client:
const HttpsProxyAgent = require('https-proxy-agent');
const token = process.env.BOT_TOKEN;

// Set proxy 
const proxy = new HttpsProxyAgent(process.env.http_proxy || 'http://proxy.ebiz.verizon.com:80');

// _________________________________________________________________________________

const { App} = require('@slack/bolt');

    
// ____________________________________________________________________

const app = new App({
  agent : proxy, 
  socketMode:true,  
  token: process.env.BOT_TOKEN,
  signingSecret: process.env.SIGNING_SECRET,
  appToken: process.env.APP_TOKEN
  
});
console.log("starting port");
///////////////////////////////////////////////////////////////////
// global.bot_uc = "UC721";
// global.bot_message = "Failed";
// global.bot_user_email = "vztest@example.com";
// global.bot_environment = "DEV"
// global.bot_host_name = "Sample_Host"

// global.approve_status = "";
// global.user_selection = "NONE";

// var main_dict = {
//     bot_uc : "UC721",
//     bot_message : "Failed",
//     bot_user_email : "vztest@example.com",
//     bot_environment : "DEV",
//     bot_host_name : "Sample_Host",
//     block_id : "",
//     approve : "NOT_selected",
//     deny : "NOT_selected",
//     user_sel : "NOT_selected",
//     escalevel: "NOT_selected"
// }

function init_dict(){

    // Bot Alert Runner Status startDateTime Modified On
    // bot_alert  runner status startdatetime modified_on
    var main_dict = {
        bot_alert : "",
        runner : "",
        status : "",
        startdatetime : "",
        modified_on : "",
        block_id : "",
        assign : "NOT_selected",
        ignore : "NOT_selected",
        user_sel : "NOT_selected",
        escalevel: "NOT_selected",
        assigner: "NOT_selected",
        timestamp : "NOT_selected"
    }

    // bot_alert  runner status startdatetime modified_on
    // bot_alert1 = main_dict["bot_alert"];
    // runner1 = main_dict["runner"];
    // status1 = main_dict["status"];
    // startdatetime1 = main_dict["startdatetime"];
    // modified_on1 = main_dict["modified_on"];
    // block_id1 = main_dict["block_id"];
    // assign1 = main_dict["assign"];
    // ignore1 = main_dict["ignore"];
    // user_sel1 = main_dict["user_sel"];
    // escalevel1 = main_dict["escalevel"];
    // assigner1 = main_dict["assigner"];
    // timestamp1 = main_dict["timestamp"];

    console.log(`Bot Alert inside init block: ${main_dict["bot_alert"]}`)

    
    // return bot_alert1,runner1, status1, startdatetime1, modified_on1, block_id1, assign1, ignore1, user_sel1, escalevel1, assigner1,timestamp1;

}

// bot_uc1 = main_dict["bot_uc"];
// bot_message1 = main_dict["bot_message"];
// bot_user_email1 = main_dict["bot_user_email"];
// bot_environment1 = main_dict["bot_environment"];
// bot_host_name1 = main_dict["bot_host_name"];
// block_id1 = main_dict["block_id"];
// approve1 = main_dict["approve"];
// deny1 = main_dict["deny"];
// user_sel1 = main_dict["user_sel"];
// escalevel1 = main_dict["escalevel"];



function update_Function(bot_alert1,runner1, status1, startdatetime1, modified_on1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1) {

    var dict = {
        bot_alert : bot_alert1,
        runner : runner1,
        status : status1 ,
        startdatetime : startdatetime1,
        modified_on : modified_on1,
        block_id : block_id1,
        assign : assign1,
        ignore: ignore1,
        user_sel : user_sel1,
        escalevel : escalevel1,
        assigner : assigner1,
        timestamp : timestamp1
    }

    return dict;   
  }

// _______________________________________________________________
function send_email(body_email){
    const { spawn } = require('child_process');
    
    const childPython = spawn('python', ['email_script.py',`${body_email}`]);
    
    childPython.stdout.on('data', (data) => {
        console.log(`stdout: ${data}`);
    })
    
    childPython.stderr.on('data', (data) => {
        console.error(`stderr: ${data}`);
    })
    
    childPython.on('close', (code) => {
        console.log(`child process exited with code ${code}`);
    })
}


// _________________________________________________________________


////////////////////////////////////////////////////////////////

(async () => {
    // Start the app
    await app.start(process.env.PORT || '3200');
  
    console.log('⚡️ Bolt app is running!');
  
  })();

/////////////////////////////////////

app.event('message', async ({ event, client }) => {

    ///////
    console.log(event)

    let source = `${event.text}`;

    var initialize_params = init_dict();

    initialize_params

    let auth_user_source = `${event.user}`;


    // Splitting the alert message__________________________________________________________________________
    let incoming_message = source;

    // console.log(incoming_message)
    // U01JS47M7LM
    
    if(auth_user_source == "U01JS47M7LM") // This condition is to split only the Bot's alert message, the user ID is the Bot's ID

    {
        const myArr = incoming_message.split(",");
        bot_alert1= myArr[0].split(":");
        runner1= myArr[1].split(":");
        status1 = myArr[2].split(":");

        let temp1 = myArr[3].split(",");
        let temp2 = myArr[4].split(",");
        
        startdatetime1 = temp1[0].split("e :");
        modified_on1 = temp2[0].split("n :");


        bot_alert1 = bot_alert1[1]
        runner1= runner1[1]
        status1 = status1[1]
        startdatetime1 = startdatetime1[1]
        modified_on1 = modified_on1[1]
        
        console.log(`Bot Alert : ${bot_alert1} \n Runner : ${runner1} \n Status : ${status1} \n startDateTime : ${startdatetime1} \n Modified On: ${modified_on1}`)
       
    }
    




    // _____________________________________________________________________________________________________

    // var userId =`${event.user}`;
  
    // // Call the users.info method using the WebClient
    // const result = await client.users.info({
    //   user: userId
    // });
  
    // console.log(result);

   

    // Test App channel: D01N8AW7USC
    // Common private channel (chatbot-test): G01KKB1CYBT
    // Milo channel : D01KUTM8CQG
    console.log(source.search("control_room"))

// if(source.search("control_room") != -1 && auth_user_source == "B01KFH9S5T3") 
// U01JS47M7LM
if(auth_user_source == "U01JS47M7LM") 
  {
    try{
        app.client.chat.postMessage({
              token: process.env.BOT_TOKEN,
              channel: "G01KKB1CYBT",
              "blocks": [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": "Bot Alert\n",
                       
                    }
                },
                {
                    "type": "section",
                    "fields": [
                        {
                            "type": "mrkdwn",
                            "text": `*Bot Alert *\n ${bot_alert1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `*Runner *\n ${runner1}\n`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `\n\n*Status *\n\n${status1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `\n\n*startDateTime *\n${startdatetime1}\n`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `\n\n*Modified On *\n ${modified_on1}`
                        }
                    ]
                },
                {
                    "type": "actions",
                    "elements": [
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "emoji": true,
                                "text": "Assign"
                            },
                            "style": "primary",
                            "value": `\n*Bot Alert: *${bot_alert1}\n*Runner: *${runner1}\n*Status: *${status1}\n*startDateTime: *${startdatetime1}\n*Modified On: *${modified_on1}`,
                            "action_id" : `assign_button`
                            
                        },
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "emoji": true,
                                "text": "Ignore"
                            },
                            "style": "danger",
                            "value": `\n*Bot Alert: *${bot_alert1}\n*Runner: *${runner1}\n*Status: *${status1}\n*startDateTime: *${startdatetime1}\n*Modified On: *${modified_on1}`,
                            "action_id" : `ignore_button`
                        }
                        ,
                        {
                            "type": "users_select",                           
                            "placeholder": {
                                "type": "plain_text",
                                "text": "Select a user",
                                "emoji": true
                            },
                            "action_id": "user_actionId"
                        },
                        {
                            "type": "static_select",
                            "placeholder": {
                                "type": "plain_text",
                                "text": "Select the Priority Level",
                                "emoji": true
                            },
                            "options": [
                                {
                                    "text": {
                                        "type": "plain_text",
                                        "text": "*High*",
                                        "emoji": true
                                    },
                                    "value": `value-0`
                                },
                                {
                                    "text": {
                                        "type": "plain_text",
                                        "text": "*Medium*",
                                        "emoji": true
                                    },
                                    "value": "value-1"
                                },
                                {
                                    "text": {
                                        "type": "plain_text",
                                        "text": "*Low*",
                                        "emoji": true
                                    },
                                    "value": "value-2"
                                }
                            ],
                            "action_id": `escalation_actionId`
                        }
                        
                    ]
                }
            ]
    
    
          })
          
           
      } 
      
      catch (error) {
          console.error(error);
      }
    }
      
});


app.action('assign_button', async ({ action, ack, say, context, body}) => {
   
    console.log('assign button clicked');
    console.log('Waiting');
    function sleep(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
      }
    console.log("waiting");
    // sleep(30000).then(() => {
    //     console.log("timeout complete");
    //   });
 
  
 
    console.log('Checking Block values')
    console.log(body.state.values)
    // console.log(body.message.blocks[2].elements[0].action_id);
    // console.log(body.message.blocks[2].elements[0].value);
    // console.log(body.message.blocks[2].elements[1].action_id);
    // console.log(body.message.blocks[2].elements[1].value);
    // console.log(body.message.blocks[2].elements[3].action_id);
    // console.log(body.message.blocks[2].elements[3].options[0].value);


    // console.log(client);
// _____________________________________

// var userId = "U01JS47M7LM"
// const result =  await client.users.info({
//     user: userId
//   });


// console.log(result)

// _______________________________________

    // _________________________________________________________________
    console.log("checking block id")
    console.log("Displaying state values under assign block")
    block_id1 = `${action.block_id}`

    // body_email = `${action.value}`

    console.log(body.state.values[block_id1].user_actionId.selected_user)

    var user_selection_checker = `${body.state.values[block_id1].user_actionId.selected_user}`

    var priority_selection_checker = `${body.state.values[block_id1].escalation_actionId.selected_option}`

    

    if(user_selection_checker === "null" || priority_selection_checker === "null"){
        await say("You have not selected the User or the Priority Level! ⚠️ \n\n *Note:* Once you have selected both the *User* and the *Priority Level*, Click Assign ")
    }
    else{

        var priority_level = `${body.state.values[block_id1].escalation_actionId.selected_option.text.text}`
        // await say(`Thank you! You just clicked the Assign button for \n____________________\n*Block ID: *${action.block_id}\n____________________${action.value} \n\n *Assigned by: * <@${body.user.id}> ✅\n\n The task is assigned to <@${user_selection_checker}> with the Priority Level ${priority_level} \n________________________________ `);
        // sleep(5000).then(() => {
        await say(`Waiting for AYS Ticket to be created for Block ID *Block ID: * ${action.block_id}`)
        await sleep(2000)

        var assigner_userID = `${body.user.id}`

        try {
            // Call the users.info method using the WebClient
            const assigner_userID_result = await app.client.users.info({
              user: assigner_userID
            });

            console.log("PRINTING ASSIGNER USER id")
            console.log(assigner_userID_result);
          }
          catch (error) {
            console.error(error);
          }
        //__________________________________
        // Block to create CSV file : start
        // const fs = require('fs')
        // var Output = [
        //     {
        //         "Block ID": `${block_id1}`,
        //         "Bot Alert": `${bot_alert1}`,
        //         "Runner": `${runner1}`,
        //         "Status": `${status1}`,
        //         "StartDateTime": `${startdatetime1}`,
        //         "Modified On": `${modified_on1}`,
        //         "Assignor": `${body.user.id}`,
        //         "Assignee": `${user_selection_checker}`,
        //         "Priority Level": `${priority_level}`
        //     }
        // ]
        // Block to create CSV file : end
        var fs = require('fs');
        var csv = require('fast-csv');
        var csv_file_name = `Bot Alert BLock_ID_${block_id1} `
        var ws = fs.createWriteStream(`${csv_file_name}.csv`);
        csv.write(
            [
                ["Block ID" ,`${block_id1}`],
                ["Bot Alert", `${bot_alert1}`],
                ["Runner", `${runner1}`],
                ["Status",`${status1}`],
                ["StartDateTime", `${startdatetime1}`],
                ["Modified On", `${modified_on1}`],
                ["Assignor", `${body.user.id}`],
                ["Assignee" , `${user_selection_checker}`],
                ["Priority Level" , `${priority_level}`]

            ],{headers:true}
            ).pipe(ws);
        // Block to create CSV file : end








        await say(`Created AYS ticket .................\n____________________\n*Block ID: * ${action.block_id}\n____________________\n________________________________________${action.value} \n\n *Assigned by: * <@${body.user.id}> ✅\n\n The task is assigned to <@${user_selection_checker}> with the Priority Level ${priority_level} with *AYS: * RITM0001234567\n________________________________ `);
    
        // body_email = `\n____________________\n*Block ID: *${action.block_id}\n____________________${action.value} \n\n *Assigned by: * <@${body.user.id}> ✅\n\n The task is assigned to <@${user_selection_checker}> with the Priority Level ${priority_level} \n________________________________ `
        // For email
        // body_email = `${action.value}`
        // notify = send_email(body_email)
        // console.log(notify)
        app.client.chat.update({
            token: process.env.BOT_TOKEN,
            channel: `${body.channel.id}`,
            ts:`${body.message.ts}`,
            "blocks": [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": `Chat has been updated for ${action.block_id}\n`
                       
                    }
                }
            ]
            
        })
//________________________________________________________________
        // Write output to the text fiile
        // Requiring fs module in which
        // 
        // writeFile function is defined.
        
    //     const fs = require('fs')
    //     // Data which will write in a file.

       
        
    //     let data = ` ${action.value}\n`
    //     // Write data in 'Output.txt' .
    //     fs.writeFile('Output.txt', data, (err) => {
    //     // In case of a error throw err.
    //     if (err) throw err;
    // })
// _______________________________________
    }

  

    // ________________________________________________________________

    assigner1 = `${body.user.id}`

    // await say(`Thank you! You just clicked the Assign button for ${action.value} done by <@${body.user.id}> , \n\n *Now select the user that needs to be assigned to the task*`);
    
    // await console.log("Message was sent")

    assign_status = true;
    // await console.log(Boolean(assign_status))
    block_id1 = `${action.block_id}`
    ignore_status = false
    assign1 = Boolean(assign_status)

    ignore1 = Boolean(ignore_status)

    
    // ______________________________________________________________________
    // Retreive timestamp
    var ts1 = Number(`${action.action_ts}`)
    var ts = ts1*1000;
    var date = new Date(ts);
    var timestamp1 = ("Date: "+date.getDate()+
          "/"+(date.getMonth()+1)+
          "/"+date.getFullYear()+
          " "+date.getHours()+
          ":"+date.getMinutes()+
          ":"+date.getSeconds());
    // _______________________________________________________________________
    // Dictionary update 
    var escalevel1 = priority_level;
    var user_sel1 = user_selection_checker;

    tracking = update_Function(bot_alert1,runner1, status1, startdatetime1, modified_on1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1)
    console.log(tracking)

    

    
  })


// /////////////////////

app.action('ignore_button', async ({ action, ack, say, context, body }) => {
    console.log('ignore button clicked');
    
    // Acknowledge action request
    console.log(action)

    assigner1 = `${body.user.id}`
  
    console.log(action.value)
    await say(`Block ID: ${action.block_id}: Thank you! You just clicked the Ignore button for ${action.value} done by <@${body.user.id}> `);
    

    ignore_status = true;
    await console.log(Boolean(ignore_status))
    block_id1 = `${action.block_id}`
    ignore1 = Boolean(ignore_status)
        // ______________________________________________________________________
    // Retreive timestamp
    var ts1 = Number(`${action.action_ts}`)
    var ts = ts1*1000;
    var date = new Date(ts);
    var timestamp1 = ("Date: "+date.getDate()+
          "/"+(date.getMonth()+1)+
          "/"+date.getFullYear()+
          " "+date.getHours()+
          ":"+date.getMinutes()+
          ":"+date.getSeconds());
    // _______________________________________________________________________

    // tracking = update_Function(bot_alert1,runner1, status1, startdatetime1, modified_on1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1)
    // console.log(tracking)

    

    
  });


//////////////////////////////////
app.action('user_actionId', async ({ action, ack, say,context,body }) => {
    console.log('user selection button clicked');
   
    console.log('Wait ended');
    // Acknowledge action request
    await ack();
    console.log(body.state.values)

  
    
    assigner1 = `${body.user.id}`


    
    // const output = outcome
    // await esfunc();
    // await console.log(output)

    // global.user_selection = `${action.selected_user}`
    // user_selection = `<@${action.selected_user}>`
    block_id1 = `${action.block_id}`
    user_sel1 = `<@${action.selected_user}>`

    // var tracking = update_Function(bot_alert1,runner1, status1, startdatetime1, modified_on1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1)
    // console.log(tracking)

    

    await say(`Block ID: ${action.block_id} You have assigned the user <@${action.selected_user}> `);
    // var tracking = update_Function(bot_alert1,runner1, status1, startdatetime1, modified_on1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1)
    // console.log(tracking)
    
  });




////////////////////////////////

app.action('escalation_actionId', async ({ action, ack, say, context,body }) => {
    console.log('button clicked');
    
    console.log(body);
    // Acknowledge action request
    await ack();
    await console.log(action)

    assigner1 = `${body.user.id}`
    block_id1 = `${action.block_id}`

    var escalevel1 = `${action.block_id}`



    // ____________________________________________________
  
  

    // ___________________________________________________

    await say(`Block ID: ${action.block_id} Thank you for selecting the escalation level ${action.selected_option.text.text} `);
    var escalevel1 = (`${action.selected_option.text.text}`)
 
    // var tracking = update_Function(bot_alert1,runner1, status1, startdatetime1, modified_on1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1)
    // console.log(tracking)


    
  });


//   Log into a file

var fs = require('fs');
var util = require('util');
var log_file = fs.createWriteStream(__dirname + '/debug.log', {flags : 'w'});
var log_stdout = process.stdout;

console.log = function(d) { //
  log_file.write(util.format(d) + '\n');
  log_stdout.write(util.format(d) + '\n');
};