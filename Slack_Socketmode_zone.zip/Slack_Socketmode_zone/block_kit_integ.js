require('dotenv').config();
// Setup the Proxy for the Web client:
const HttpsProxyAgent = require('https-proxy-agent');
const token = process.env.BOT_TOKEN;

// Set proxy 
const proxy = new HttpsProxyAgent(process.env.http_proxy || 'http://proxy.ebiz.verizon.com:80');

// _________________________________________________________________________________

const { App} = require('@slack/bolt');

    
// ____________________________________________________________________

const app = new App({
  agent : proxy, 
  socketMode:true,  
  token: process.env.BOT_TOKEN,
  signingSecret: process.env.SIGNING_SECRET,
  appToken: process.env.APP_TOKEN
  
});
console.log("starting port");
/* Add functionality here */  

(async () => {
  // Start the app
  await app.start(process.env.PORT || '3200');

  console.log('⚡️ Bolt app is running!');

})();

app.event('message', async ({ event, client }) => {

  ///////
 
  console.log(event)
  var source = `${event.text}`

  var user_interacted = `${event.user}`


if(source=="control_room")
{

var bot_uc = "UC721";
var bot_message = "Failed";
var bot_user_email = "vztest@example.com";
var bot_environment = "DEV"
var bot_host_name = "Sample_Host"

// var main_dict = {
//     bot_uc : "UC721",
//     bot_message : "Failed",
//     bot_user_email : "vztest@example.com",
//     bot_environment : "DEV",
//     bot_host_name : "Sample_Host",
//     // block_id : "",
//     // approve : "NOT_selected",
//     // deny : "NOT_selected",
//     // user_sel : "NOT_selected",
//     // escalevel: "NOT_selected"
// }



// var bot_uc1 = main_dict["bot_uc"];
// var bot_message1 = main_dict["bot_message"];
// var bot_user_email1 = main_dict["bot_user_email"];
// var bot_environment1 = main_dict["bot_environment"];
// var bot_host_name1 = main_dict["bot_host_name"];
// global.block_id1 = main_dict["block_id"];
// global.approve1 = main_dict["approve"];
// global.deny1 = main_dict["deny"];
// global.user_sel1 = main_dict["user_sel"];
// global.escalevel1 = main_dict["escalevel"];

// function update_Function(bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1,block_id1,approve1,deny1,user_sel1,escalevel1) {

//     var dict = {
//         bot_uc : bot_uc1,
//         bot_message : bot_message1,
//         bot_user_email : bot_user_email1 ,
//         bot_environment : bot_environment1,
//         bot_host_name : bot_host_name1,
//         block_id : block_id1,
//         approve : approve1,
//         deny: deny1,
//         user_sel : user_sel1,
//         escalevel : escalevel1
//     }

//     return dict;   
//   }
// /////
try{
    app.client.chat.postMessage({
          token: process.env.BOT_TOKEN,
          channel: "D01N8AW7USC",
          "blocks": [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "Bot Alert\n",
                   
                }
            },
            {
                "type": "section",
                "fields": [
                    {
                        "type": "mrkdwn",
                        "text": `*Bot Name *\n ${bot_uc}`
                    },
                    {
                        "type": "mrkdwn",
                        "text": `*Bot Message*\n ${bot_message}`
                    },
                    {
                        "type": "mrkdwn",
                        "text": `*User Email*\n${bot_user_email}`
                    },
                    {
                        "type": "mrkdwn",
                        "text": `*Environment*\n${bot_environment}`
                    },
                    {
                        "type": "mrkdwn",
                        "text": `*Host name*\n ${bot_host_name}`
                    }
                ]
            },
            {
                "type": "actions",
                "elements": [
                    {
                        "type": "button",
                        "text": {
                            "type": "plain_text",
                            "emoji": true,
                            "text": "Approve"
                        },
                        "style": "primary",
                        "value": `${bot_uc}_${bot_message}_${bot_host_name}_${bot_user_email}_${bot_environment}_done_by_<@${user_interacted}>`,
                        "action_id" : `approve_button`
                        
                    },
                    {
                        "type": "button",
                        "text": {
                            "type": "plain_text",
                            "emoji": true,
                            "text": "Deny"
                        },
                        "style": "danger",
                        "value": `${bot_uc1}_${bot_message}_${bot_host_name}_${bot_user_email}_${bot_environment}_done_by_<@${user_interacted}>`,
                        "action_id" : `deny_button`
                    }
                    ,
                    {
                        "type": "users_select",                           
                        "placeholder": {
                            "type": "plain_text",
                            "text": "Select a user",
                            "emoji": true
                        },
                        "action_id": "user_actionId"
                    },
                    {
                        "type": "static_select",
                        "placeholder": {
                            "type": "plain_text",
                            "text": "Select an item",
                            "emoji": true
                        },
                        "options": [
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "*High*",
                                    "emoji": true
                                },
                                "value": `value-0`
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "*Medium*",
                                    "emoji": true
                                },
                                "value": "value-1"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "*Low*",
                                    "emoji": true
                                },
                                "value": "value-2"
                            }
                        ],
                        "action_id": `escalation_actionId`
                    }
                    
                ]
            }
        ]


      })
      
       
  } 

    catch (error) {
      console.error(error.data);
    }
    
  }
});


app.action('approve_button', async ({ action, ack, say, context, }) => {
    console.log('button clicked');

    // Acknowledge action request
  
    await ack();
    console.log(ack)
    await console.log(context)

    console.log(action)

    
    console.log(action.value)
    await say(`Thank you! You just clicked the Approve button for ${action.value} , \n\n *Now select the user that needs to be assigned to the task*`);
    
    await console.log("Message was sent")

    approve_status = true;
    await console.log(Boolean(approve_status))
    // block_id1 = `${action.block_id}`

    // update_Function(bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1,block_id1,approve1,deny1,user_sel1,escalevel1)
    // console.log(dict)

    
  })


app.action('deny_button', async ({ action, ack, say, context }) => {
    console.log('button clicked');
    
    // Acknowledge action request
    console.log(action)
  
    console.log(action.value)
    await say(`Thank you! You just clicked the Deny button for ${action.value} , \n\n *Now select the user that needs to be assigned to the task*`);
    

    approve_status = false ;

    
  });




app.action('user_actionId', async ({ action, ack, say,context }) => {
    console.log('button clicked');
    
    // Acknowledge action request
    await ack();

  
    await console.log(action)
    await console.log(context)
    await console.log(ack)

    


    
    // const output = outcome
    // await esfunc();
    // await console.log(output)

    // global.user_selection = `${action.selected_user}`
    // user_selection = `<@${action.selected_user}>`

    

    await say(`You have selected the user assigned to <@${action.selected_user}> \n\n  *Now select the escalation level of the task*`);

    
  });





app.action('escalation_actionId', async ({ action, ack, say, context }) => {
    console.log('button clicked');
    
    // Acknowledge action request
    await ack();
    await console.log(action)

   


    await say(`Thank you for selecting the escalation level ${action.selected_option.text.text} `);
    const output = (`${action.selected_option.text.text}`)
    await output
    await console.log(output)
    return output

    
  });



// app.action('message', async ({ action, ack, respond }) => {
//     await ack();
//     await respond(`You selected <@${action.selected_user}>`);
//   });







 


















   
  

























