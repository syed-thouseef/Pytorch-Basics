require('child_process')
var exec = require('child_process').execFile;

var fun =function(){
   console.log("fun() start");
   exec('test_note.exe', function(err, data) {  
        console.log(err)
        console.log(data.toString());                       
    });  
}
fun();