// var result;
// result = "BotName,BotMessage,UserEmail,Environment,HostName".split(","); 
// console.log(result);


// var someData = [
//     {
//         "Country": "Nigeria",
//         "Population": "200m",
//         "Continent": "Africa",
//         "Official Language(s)": "English"
//     }
// ]


var fs = require('fs');
var csv = require('fast-csv');
var ws = fs.createWriteStream('test.csv');

csv.write(
    [
        ['1','2']
    ],{headers:true}
).pipe(ws);