require('dotenv').config();
// Setup the Proxy for the Web client:
const HttpsProxyAgent = require('https-proxy-agent');
const token = process.env.BOT_TOKEN;

// Set proxy 
const proxy = new HttpsProxyAgent(process.env.http_proxy || 'http://proxy.ebiz.verizon.com:80');

// _________________________________________________________________________________

const { App} = require('@slack/bolt');

    
// ____________________________________________________________________

const app = new App({
  agent : proxy, 
  socketMode:true,  
  token: process.env.BOT_TOKEN,
  signingSecret: process.env.SIGNING_SECRET,
  appToken: process.env.APP_TOKEN
  
});
console.log("starting port");
///////////////////////////////////////////////////////////////////
// global.bot_uc = "UC721";
// global.bot_message = "Failed";
// global.bot_user_email = "vztest@example.com";
// global.bot_environment = "DEV"
// global.bot_host_name = "Sample_Host"

// global.approve_status = "";
// global.user_selection = "NONE";

// var main_dict = {
//     bot_uc : "UC721",
//     bot_message : "Failed",
//     bot_user_email : "vztest@example.com",
//     bot_environment : "DEV",
//     bot_host_name : "Sample_Host",
//     block_id : "",
//     approve : "NOT_selected",
//     deny : "NOT_selected",
//     user_sel : "NOT_selected",
//     escalevel: "NOT_selected"
// }

function init_dict(){
    var main_dict = {
        bot_uc : "UC721",
        bot_message : "Failed",
        bot_user_email : "vztest@example.com",
        bot_environment : "PROD",
        bot_host_name : "Sample_Host",
        block_id : "",
        assign : "NOT_selected",
        ignore : "NOT_selected",
        user_sel : "NOT_selected",
        escalevel: "NOT_selected",
        assigner: "NOT_selected",
        timestamp : "NOT_selected"
    }


    bot_uc1 = main_dict["bot_uc"];
    bot_message1 = main_dict["bot_message"];
    bot_user_email1 = main_dict["bot_user_email"];
    bot_environment1 = main_dict["bot_environment"];
    bot_host_name1 = main_dict["bot_host_name"];
    block_id1 = main_dict["block_id"];
    assign1 = main_dict["assign"];
    ignore1 = main_dict["ignore"];
    user_sel1 = main_dict["user_sel"];
    escalevel1 = main_dict["escalevel"];
    assigner1 = main_dict["assigner"];
    timestamp1 = main_dict["timestamp"];

    
    return bot_uc1,bot_message1, bot_user_email1, bot_environment1, bot_host_name1, block_id1, assign1, ignore1, user_sel1, escalevel1, assigner1,timestamp1;

}

// bot_uc1 = main_dict["bot_uc"];
// bot_message1 = main_dict["bot_message"];
// bot_user_email1 = main_dict["bot_user_email"];
// bot_environment1 = main_dict["bot_environment"];
// bot_host_name1 = main_dict["bot_host_name"];
// block_id1 = main_dict["block_id"];
// approve1 = main_dict["approve"];
// deny1 = main_dict["deny"];
// user_sel1 = main_dict["user_sel"];
// escalevel1 = main_dict["escalevel"];



function update_Function(bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1) {

    var dict = {
        bot_uc : bot_uc1,
        bot_message : bot_message1,
        bot_user_email : bot_user_email1 ,
        bot_environment : bot_environment1,
        bot_host_name : bot_host_name1,
        block_id : block_id1,
        assign : assign1,
        ignore: ignore1,
        user_sel : user_sel1,
        escalevel : escalevel1,
        assigner : assigner1,
        timestamp : timestamp1
    }

    return dict;   
  }


////////////////////////////////////////////////////////////////

(async () => {
    // Start the app
    await app.start(process.env.PORT || '3200');
  
    console.log('⚡️ Bolt app is running!');
  
  })();

/////////////////////////////////////

app.event('message', async ({ event, client }) => {

    ///////
    console.log(event)

    var source = `${event.text}`;

    var assigner1 = `${event.user}`;

    var initialize_params = init_dict();

    initialize_params

  



    

  
  
if(source.search("control room"))
  {

    try{
        app.client.chat.postMessage({
              token: process.env.BOT_TOKEN,
              channel: "D01N8AW7USC",
              "blocks": [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": "Bot Alert\n",
                       
                    }
                },
                {
                    "type": "section",
                    "fields": [
                        {
                            "type": "mrkdwn",
                            "text": `*Bot Name *\n ${bot_uc1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `*Bot Message*\n ${bot_message1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `*User Email*\n${bot_user_email1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `*Environment*\n${bot_environment1}`
                        },
                        {
                            "type": "mrkdwn",
                            "text": `*Host name*\n ${bot_host_name1}`
                        }
                    ]
                },
                {
                    "type": "actions",
                    "elements": [
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "emoji": true,
                                "text": "Assign"
                            },
                            "style": "primary",
                            "value": `${bot_uc1}_${bot_message1}_${bot_host_name1}_${bot_user_email1}_${bot_environment1}_done_by_<@${assigner1}>`,
                            "action_id" : `assign_button`
                            
                        },
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "emoji": true,
                                "text": "Ignore"
                            },
                            "style": "danger",
                            "value": `${bot_uc1}_${bot_message1}_${bot_host_name1}_${bot_user_email1}_${bot_environment1}_done_by_<@${assigner1}>`,
                            "action_id" : `ignore_button`
                        }
                        ,
                        {
                            "type": "users_select",                           
                            "placeholder": {
                                "type": "plain_text",
                                "text": "Select a user",
                                "emoji": true
                            },
                            "action_id": "user_actionId"
                        },
                        {
                            "type": "static_select",
                            "placeholder": {
                                "type": "plain_text",
                                "text": "Select the Priority Level",
                                "emoji": true
                            },
                            "options": [
                                {
                                    "text": {
                                        "type": "plain_text",
                                        "text": "*High*",
                                        "emoji": true
                                    },
                                    "value": `value-0`
                                },
                                {
                                    "text": {
                                        "type": "plain_text",
                                        "text": "*Medium*",
                                        "emoji": true
                                    },
                                    "value": "value-1"
                                },
                                {
                                    "text": {
                                        "type": "plain_text",
                                        "text": "*Low*",
                                        "emoji": true
                                    },
                                    "value": "value-2"
                                }
                            ],
                            "action_id": `escalation_actionId`
                        }
                        
                    ]
                }
            ]
    
    
          })
          
           
      } 
      
      catch (error) {
          console.error(error);
      }
    }
      
});

app.action('assign_button', async ({ action, ack, say, context, client}) => {
    console.log('button clicked');
// ______________________________________________

// _______________________________________________
    // Acknowledge action request
  
    await ack();
    console.log(ack)
    await console.log(context)

    console.log(action)

    
    console.log(action.value)
    await say(`Thank you! You just clicked the Assign button for ${action.value} , \n\n *Now select the user that needs to be assigned to the task*`);
    
    await console.log("Message was sent")

    assign_status = true;
    await console.log(Boolean(assign_status))
    block_id1 = `${action.block_id}`
    assign1 = Boolean(assign_status)

    assigner1 = `${action.value}`
    // ______________________________________________________________________
    // Retreive timestamp
    var ts1 = Number(`${action.action_ts}`)
    var ts = ts1*1000;
    var date = new Date(ts);
    var timestamp1 = ("Date: "+date.getDate()+
          "/"+(date.getMonth()+1)+
          "/"+date.getFullYear()+
          " "+date.getHours()+
          ":"+date.getMinutes()+
          ":"+date.getSeconds());
    // _______________________________________________________________________

    tracking = update_Function(bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1)
    console.log(tracking)

    

    
  })


// /////////////////////


app.action('ignore_button', async ({ action, ack, say, context }) => {
    console.log('button clicked');
    
    // Acknowledge action request
    console.log(action)
  
    console.log(action.value)
    await say(`Thank you! You just clicked the Ignore button for ${action.value} , \n\n *Now select the user that needs to be assigned to the task*`);
    

    ignore_status = true;
    await console.log(Boolean(ignore_status))
    block_id1 = `${action.block_id}`
    ignore1 = Boolean(ignore_status)
        // ______________________________________________________________________
    // Retreive timestamp
    var ts1 = Number(`${action.action_ts}`)
    var ts = ts1*1000;
    var date = new Date(ts);
    var timestamp1 = ("Date: "+date.getDate()+
          "/"+(date.getMonth()+1)+
          "/"+date.getFullYear()+
          " "+date.getHours()+
          ":"+date.getMinutes()+
          ":"+date.getSeconds());
    // _______________________________________________________________________

    tracking = update_Function(bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1)
    console.log(tracking)

    

    
  });


//////////////////////////////////
app.action('user_actionId', async ({ action, ack, say,context }) => {
    console.log('button clicked');
    
    // Acknowledge action request
    await ack();

  
    await console.log(action)
    await console.log(context)
    await console.log(ack)

    


    
    // const output = outcome
    // await esfunc();
    // await console.log(output)

    // global.user_selection = `${action.selected_user}`
    // user_selection = `<@${action.selected_user}>`
    block_id1 = `${action.block_id}`
    user_sel1 = `<@${action.selected_user}>`

    var tracking = update_Function(bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1)
    console.log(tracking)

    

    await say(`You have selected the user assigned to <@${action.selected_user}> \n\n  *Now select the escalation level of the task*`);

    
  });




////////////////////////////////

app.action('escalation_actionId', async ({ action, ack, say, context }) => {
    console.log('button clicked');
    
    // Acknowledge action request
    await ack();
    await console.log(action)

   


    await say(`Thank you for selecting the escalation level ${action.selected_option.text.text} `);
    var escalevel1 = (`${action.selected_option.text.text}`)
 
    var tracking = update_Function(bot_uc1,bot_message1,bot_user_email1, bot_environment1,bot_host_name1,block_id1,assign1,ignore1,user_sel1,escalevel1,assigner1,timestamp1)
    console.log(tracking)


    
  });