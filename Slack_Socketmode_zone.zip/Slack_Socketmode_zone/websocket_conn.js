// npm i ws

const WebSocket = require('ws');

const url = 'wss://wss-primary.slack.com/link/?ticket=f663cfed-544d-4fad-bade-4db6ad620494&app_id=1c874b5a6eff2713516a553b8b5b951dd26291154ea0a4c979d989f810473b4c'
var socket = new WebSocket(url)

// socket.onopen = () => function(e) {
//     // connection established
//   }
  
// socket.onmessage = function(event) {
//     // application received message
//   }



// Open the socket
socket.onopen = function(e) {

    // Send an initial message
    socket.send('I am the client and I\'m listening!');

    // Listen for messages
    // socket.onmessage = function(event) {
    //     console.log('Client received a message',event);
    // };

    // // Listen for socket closes
    // socket.onclose = function(event) {
    //     console.log('Client notified socket has closed',event);
    // };

    // // To close the socket....
    // socket.close()

};


socket.onmessage = function(event) {
   
};








