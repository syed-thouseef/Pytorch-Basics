let incoming_message = "*Bot Alert*: _UC879_CallScriptGeneration_201903_Main.atmx_, Runner : WTPAVPA08KW0175, Status : *RUN_ABORTED*, startDateTime : 08/25/2021 17:00:19, Modified On : 08/25/2021 17:40:34";


let incoming_message_2 = "Runner Alert Runner : 63-18-72-156 , Status : DISCONNECTED"

const run_alert = incoming_message_2.split(",");


let runner_info_message = run_alert[0].split(":");
let runner_status_message = run_alert[1].split(":");

runner_info_message= runner_info_message[1].split("r :");
runner_status_message  = runner_status_message[1]

console.log(`Runner : ${runner_info_message}\nStatus : ${runner_status_message } `)

// let Bot_Alert = myArr[0].split(":");
// let Runner = myArr[1].split(":");
// let Status = myArr[2].split(":");


// let temp1 = myArr[3].split(",")
// let temp2 = myArr[4].split(",")

// let startDateTime = temp1[0].split("e :");
// let Modified_On = temp2[0].split("n :");

// Bot_Alert = Bot_Alert[1]
// Runner = Runner[1]
// Status = Status[1]
// startDateTime = startDateTime[1]
// Modified_On = Modified_On[1]

// console.log(`Bot Alert : ${Bot_Alert} \n Runner : ${Runner} \n Status : ${Status} \n startDateTime : ${startDateTime} \n Modified On: ${Modified_On}`)

