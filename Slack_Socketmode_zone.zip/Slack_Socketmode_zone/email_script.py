import sys

import smtplib, ssl
from email.mime.text import MIMEText

sender = 'no-reply@verizon.com'
receivers = ['thouseef.syed@verizon.com']

# body_of_email = """From: From Person <from@fromdomain.com>
# To: To Person <to@todomain.com>
# Subject: SMTP e-mail test

# This is a test e-mail message.
# """
body_of_email=str(sys.argv[1])

msg = MIMEText(body_of_email, 'html')

try:

    s= smtplib.SMTP(host='smtp.verizon.com',port=25)
    s.sendmail(sender,receivers,msg.as_string())
    s.quit
    print("Email sent successfully")

except Exception as e:
   print(str(sys.argv[1]))
   print("Error: unable to send email")
