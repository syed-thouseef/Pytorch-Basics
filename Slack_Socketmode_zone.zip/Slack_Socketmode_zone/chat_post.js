require('dotenv').config();
// Setup the Proxy for the Web client:
const HttpsProxyAgent = require('https-proxy-agent');
const token = process.env.BOT_TOKEN;

// Set proxy 
const proxy = new HttpsProxyAgent(process.env.http_proxy || 'http://proxy.ebiz.verizon.com:80');

// _________________________________________________________________________________

const { App} = require('@slack/bolt');

    
// ____________________________________________________________________

const app = new App({
  agent : proxy, 
  socketMode:true,  
  token: process.env.BOT_TOKEN,
  signingSecret: process.env.SIGNING_SECRET,
  appToken: process.env.APP_TOKEN
  
});
console.log("starting port");
/* Add functionality here */  

(async () => {
  // Start the app
  await app.start(process.env.PORT || '3000');

  console.log('⚡️ Bolt app is running!');
  try{
      app.client.chat.postMessage({
          token: process.env.BOT_TOKEN,
          channel: "G01KKB1CYBT",
          "blocks": [
              {
                  "type": "section",
                  "text": {
                      "type": "mrkdwn",
                      "text": "*Bot Alert*: _UC879_CallScriptGeneration_201903_Main.atmx_, Runner : WTPAVPA08KW0175, Status : *RUN_ABORTED*, startDateTime : 08/25/2021 17:00:19, Modified On : 08/25/2021 17:40:34"
                  }
              }


          ]


      })
  }
  catch (error) {
      console.error(error);
  }
})();
