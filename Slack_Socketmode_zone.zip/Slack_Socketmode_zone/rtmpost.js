const { RTMClient } = require('@slack/rtm-api');
const token = process.env.BOT_TOKEN;
const rtm = new RTMClient(token);


rtm.on('hello', async (event) => {
  try {
    // Send a welcome message to the same channel where the new member just joined, and mention the user.
    const reply = await rtm.sendMessage(`Welcome to the channel, <@${event.user}>`, event.channel)
    console.log('Message sent successfully', reply.ts);
    
  } catch (error) {
    console.log('An error occurred', error);
  }
});

(async () => {
  await rtm.start();
})();