require('dotenv').config();
// Setup the Proxy for the Web client:
const HttpsProxyAgent = require('https-proxy-agent');
const token = process.env.BOT_TOKEN;

// Set proxy 
const proxy = new HttpsProxyAgent(process.env.http_proxy || 'http://proxy.ebiz.verizon.com:80');

// _________________________________________________________________________________

const { App} = require('@slack/bolt');

    
// ____________________________________________________________________

const app = new App({
  agent : proxy, 
  socketMode:true,  
  token: process.env.BOT_TOKEN,
  signingSecret: process.env.SIGNING_SECRET,
  appToken: process.env.APP_TOKEN
  
});
console.log("starting port");
/* Add functionality here */  

(async () => {
  // Start the app
  await app.start(process.env.PORT || '3000');

  console.log('⚡️ Bolt app is running!');
  try{
      app.client.chat.postMessage({
          token: process.env.BOT_TOKEN,
          channel: "D01N8AW7USC",
          "blocks": [
              {
                  "type": "section",
                  "text": {
                      "type": "mrkdwn",
                      "text": " Hello Everyone! \nThis the App's first message!\n\n Now you can see a picture and button! This was established using Socketmode"
                  },
                  "accessory" : {
                      "type": "image",
                      "image_url" : "https://pbs.twimg.com/profile_images/1058706213129474048/0Z-kRgbx.jpg",
                      "alt_text" : "alt text for image"

                  }
              },
              {
                  "type": "actions",
                  "elements" : [
                      {
                          "type" : "button",
                          "text" : {
                              "type" : "plain_text",
                              "text" : "Click the button!",
                              "emoji" : true
                          },
                          "value" : "clicked",
                          "action_id" : "the_button"

                      }
                  ] 
              }


          ]


      })
  }
  catch (error) {
      console.error(error);
  }
})();



app.action('the_button', async ({ action, ack, say, context }) => {
    console.log('button clicked');
    console.log(action);
    // Acknowledge action request
    await ack();
    await say('Thank you for clicking the button 👍');
  });


app.message('hello', async ({ message, say }) => {
    await say(`Hello, <@${message.user}>`);
  });



// app.action('message', async ({ action, ack, respond }) => {
//     await ack();
//     await respond(`You selected <@${action.selected_user}>`);
//   });



app.event('message', async ({ event, client }) => {
    try {
      // Call chat.postMessage with the built-in client
      const result = await client.chat.postMessage({
        token: process.env.BOT_TOKEN,
        channel: "D01N8AW7USC",
        text: `Response from script using app.events`
      });
      console.log(app.event);
    }
    catch (error) {
      console.error(error);
    }
  });



    

 
  





  












