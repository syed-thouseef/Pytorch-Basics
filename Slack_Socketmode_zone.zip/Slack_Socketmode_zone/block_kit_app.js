require('dotenv').config();
// Setup the Proxy for the Web client:
const HttpsProxyAgent = require('https-proxy-agent');
const token = process.env.BOT_TOKEN;

// Set proxy 
const proxy = new HttpsProxyAgent(process.env.http_proxy || 'http://proxy.ebiz.verizon.com:80');

// _________________________________________________________________________________

const { App} = require('@slack/bolt');

    
// ____________________________________________________________________

const app = new App({
  agent : proxy, 
  socketMode:true,  
  token: process.env.BOT_TOKEN,
  signingSecret: process.env.SIGNING_SECRET,
  appToken: process.env.APP_TOKEN
  
});
console.log("starting port");
/* Add functionality here */  

//////////////////////////////////////////////////////////////////////////////////////////////////////////////





global.bot_uc = "UC721";
global.bot_message = "Failed";
global.bot_user_email = "vztest@example.com";
global.bot_environment = "DEV"
global.bot_host_name = "Sample_Host"

global.approve_status = "";
global.user_selection = "NONE";

///////////////////////////////////////////////////////////////////////////////////////////////////////////






(async () => {
  // Start the app
  await app.start(process.env.PORT || '3000');

  console.log('⚡️ Bolt app is running!');


//   declare constant that will keep it unique for the specific alert

/////////////////////////////////////////////////////////////

// app.event('message', async ({ event, client }) => {

//     ///////
//     console.log(event)

///////////////////////////////////////////////////




  try{
    app.client.chat.postMessage({
          token: process.env.BOT_TOKEN,
          channel: "D01N8AW7USC",
          "blocks": [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "Bot Alert\n",
                   
                }
            },
            {
                "type": "section",
                "fields": [
                    {
                        "type": "mrkdwn",
                        "text": `*Bot Name *\n ${bot_uc}`
                    },
                    {
                        "type": "mrkdwn",
                        "text": `*Bot Message*\n ${bot_message}`
                    },
                    {
                        "type": "mrkdwn",
                        "text": `*User Email*\n${bot_user_email}`
                    },
                    {
                        "type": "mrkdwn",
                        "text": `*Environment*\n${bot_environment}`
                    },
                    {
                        "type": "mrkdwn",
                        "text": `*Host name*\n ${bot_host_name}`
                    }
                ]
            },
            {
                "type": "actions",
                "elements": [
                    {
                        "type": "button",
                        "text": {
                            "type": "plain_text",
                            "emoji": true,
                            "text": "Approve"
                        },
                        "style": "primary",
                        "value": `${bot_uc}_${bot_message}_${bot_host_name}_${bot_user_email}_${bot_environment}`,
                        "action_id" : `approve_button`
                        
                    },
                    {
                        "type": "button",
                        "text": {
                            "type": "plain_text",
                            "emoji": true,
                            "text": "Deny"
                        },
                        "style": "danger",
                        "value": `${bot_uc}_${bot_message}_${bot_host_name}_${bot_user_email}_${bot_environment}`,
                        "action_id" : `deny_button`
                    }
                    ,
                    {
                        "type": "users_select",                           
                        "placeholder": {
                            "type": "plain_text",
                            "text": "Select a user",
                            "emoji": true
                        },
                        "action_id": "user_actionId"
                    },
                    {
                        "type": "static_select",
                        "placeholder": {
                            "type": "plain_text",
                            "text": "Select an item",
                            "emoji": true
                        },
                        "options": [
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "*High*",
                                    "emoji": true
                                },
                                "value": `value-0`
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "*Medium*",
                                    "emoji": true
                                },
                                "value": "value-1"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "*Low*",
                                    "emoji": true
                                },
                                "value": "value-2"
                            }
                        ],
                        "action_id": `escalation_actionId`
                    }
                    
                ]
            }
        ]


      })
      
       
  } 
  
  catch (error) {
      console.error(error);
  }
  
})();




app.action('approve_button', async ({ action, ack, say, context, }) => {
    console.log('button clicked');
    
   
    
    
    // Acknowledge action request
  
    await ack();
    console.log(ack)
  
    console.log(action)
    await say(`Thank you! You just clicked the Approve button for ${bot_uc}, \n\n *Now select the user that needs to be assigned to the task*`);
    
    await console.log("Message was sent")

   

    approve_status = true;
    await console.log(Boolean(approve_status))

    



    
  })








app.action('deny_button', async ({ action, ack, say, context }) => {
    console.log('button clicked');
    
    // Acknowledge action request
    await ack();
    console.log(ack)
    await say(`Thank you! You just clicked the Deny button for ${bot_uc}`);

    approve_status = false ;

    
  });











const esfunc = async() => {
    app.action('escalation_actionId', async ({ action, ack, respond, context }) => {
        console.log('button clicked');
        
        // Acknowledge action request
        await ack();
        await console.log(action)
    
        await respond(`Thank you for selecting the escalation level ${action.selected_option.text.text} for ${bot_uc} with approve status : ${Boolean(approve_status)} || assigned to ${user_selection}`);
        const output = (`${action.selected_option.text.text}`)
        await output
        await console.log(output)
        return output
    
        
      });
      
  }

 

app.action('user_actionId', async ({ action, ack, say,context }) => {
    console.log('button clicked');
    
    // Acknowledge action request
    await ack();

  
    await console.log(action)
    await console.log(ack)


    const main_escal = async () =>{
        const outcome = await esfunc()
        return outcome
    }

    // main_escal() // returns a promise

    (async () => {
        console.log(await main_escal())
        console.log("Inside the wrapper")
      })()
    // const output = outcome
    // await esfunc();
    // await console.log(output)

    // global.user_selection = `${action.selected_user}`
    user_selection = `<@${action.selected_user}>`

    

    await say(`You have selected the user <@${action.selected_user}> assigned to ${bot_uc} \n\n  *Now select the escalation level of the task*`);

    
  });


// function esfunc() {
//     app.action('escalation_actionId', async ({ action, ack, respond, context }) => {
//         console.log('button clicked');
        
//         // Acknowledge action request
//         await ack();
//         await console.log(action)
    
//         // await respond(`Thank you for selecting the escalation level ${action.selected_option.text.text} `);
//         var output = (`${action.selected_option.text.text}`)
//         return output
    
        
//       });
//   }
  

// app.action('escalation_actionId', async ({ action, ack, respond, context }) => {
//     console.log('button clicked');
    
//     // Acknowledge action request
//     await ack();
//     await console.log(action)

//     await respond(`Thank you for selecting the escalation level ${action.selected_option.text.text} `);

    
//   });





  




















// app.message('hello', async ({ message, say }) => {
//     await say(`Hello, <@${message.user}>`);
//   });



// app.action('message', async ({ action, ack, respond }) => {
//     await ack();
//     await respond(`You selected <@${action.selected_user}>`);
//   });



// app.event('message', async ({ event, client }) => {
//     try {
//       // Call chat.postMessage with the built-in client
//       const result = await client.chat.postMessage({
//         token: process.env.BOT_TOKEN,
//         channel: "D01N8AW7USC",
//         text: `Response from script using app.events`
//       });
//       console.log(app.event);
//     }
//     catch (error) {
//       console.error(error);
//     }
//   });







