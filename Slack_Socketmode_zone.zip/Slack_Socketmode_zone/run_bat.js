// Install npm i winax
// npm install -g node-gyp
// require('winax');
// var wshShell = new ActiveXObject("WScript.Shell");
// wshShell.Run("C:/Users/syedth1/Documents/test.bat");


// const { spawn } = require('child_process');
// const bat = spawn('cmd.exe', ['/c', 'C:/Users/syedth1/Documents/test.bat']);

// bat.stdout.on('data', (data) => {
//   console.log(data.toString());
// });

// bat.stderr.on('data', (data) => {
//   console.error(data.toString());
// });

// bat.on('exit', (code) => {
//   console.log(`Child exited with code ${code}`);
// });

const { spawn } = require('child_process');
const bat = spawn('cmd.exe', ['/c', 'C:/Users/afnrtfin5-3/Documents/run_uipath_main.bat']);

bat.stdout.on('data', (data) => {
  console.log(data.toString());
});

bat.stderr.on('data', (data) => {
  console.error(data.toString());
});

bat.on('exit', (code) => {
  console.log(`Child exited with code ${code}`);
});

var ks = require('node-key-sender');

ks.sendCombination(['windows', 'd']);
ks.sendCombination(['alt', 'tab','alt','tab' ]);

ks.sendKeys(['tab']);
ks.sendKeys(['down']);
ks.sendKeys(['down']);
ks.sendKeys(['enter']);
